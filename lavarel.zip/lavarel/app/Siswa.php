<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Siswa extends Model
{
    protected $table = 'siswa';
    protected $fillable =[
        'nisn',
        'nama_siswa',
        'tanggal_lahir',
        'jenis_kelamin',
        'id_kelas',
    ];

    public function Kelas(){
        return $this->belongsto('App/Kelas','id_kelas');
    }
    public function Walikelas(){
        return $this->hasOne('App/Walikelas','id');
    }
}
