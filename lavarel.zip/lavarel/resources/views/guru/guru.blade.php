@extends('template')

@section('main')
<div id="guru"><br>
<h2 align="center">Guru</h2><br>

@if (!empty($guru_list))
<table class="table table-striped">
  <thead>
    <tr align="center">
      <th>NIP</th>
      <th>Nama</th>
      <th>Tanggal Lahir</th>
      <th>Jenis Kelamin</th>
      <th>Aksi</th>

    </tr>
  </thead>
  <tbody>
      @foreach($guru_list as $guru)
      <tr align="center" >
        <td>{{ $guru->nip }}</td>
        <td>{{ $guru->nama_guru }}</td>
        <td>{{ $guru->tanggal_lahir }}</td>
        <td>{{ $guru->jenis_kelamin }}</td>
        <td>
        <a class="btn btn-success btn-sm" href="{{ url('guru' . $guru->id) }}">Detail</a>
        <a class="btn btn-warning btn-sm" href="{{ url('edit' . $guru->id) }}">Edit</a>
        <a class="btn btn-danger btn-sm" href="{{ url('guru/' . $guru->id . '/delete') }}">Delete</a>
        </td>


      </tr>
      @endforeach
      </tbody>
    </table>

      @else
          <p>Tidak ada data guru</p>
      @endif

    <div align="center">
      <a href="{{ url('create') }}" class="btn btn-primary">Tambah Guru</a>
    </div>
    </div>
  @stop


@section('footer')
    <div id="footer">
        <p>&copy; 2019 Belajar_Laravel</p>
    </div>
@stop 