@extends('template')

@section('main')
    <div id="guru"><br>
        <h2 align="center">Detail Guru</h2>

        <table class="table table-striped">
            <tr>
            <center>
                <img class="rounded" src="{{asset('images/'.$guru->image) }}" width="350px" height="auto">
            </center>
            </tr>
            <tr>
                <th>NISN</th>
                <td>{{ $guru->nisn }}</td>
            </tr>
            <tr>
                <th>Nama</th>
                <td>{{ $guru->nama_guru }}</td>
            </tr>
            <tr>
                <th>Tanggal Lahir</th>
                <td>{{ $guru->tanggal_lahir }}</td>
            </tr>
            <tr>
                <th>Jenis Kelamin</th>
                <td>{{ $guru->jenis_kelamin }}</td>
            </tr>
        </table>
    </div>
@stop