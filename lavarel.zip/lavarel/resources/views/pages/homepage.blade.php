@extends('template')

@section('main')

<div id="homepage"><br>
    <h2 align="center">Homepage</h2>
    <p align="center">Selamat Belajar Laravel</p>
</div>

@stop 

@section('footer')
    <div id="footer">
        <p>&copy; 2019 Belajar_Laravel.ev</p>
    </div>
@stop
