@extends('template')

@section('main')
<div id="mainNav">
 
<div id="about">
    <h2 align="center">About</h2>
    <p align="center">Sistem ini dibuat sebagai latihan untuk mempelajari dasar laravel.</p>
</div>
   
</div>
@stop