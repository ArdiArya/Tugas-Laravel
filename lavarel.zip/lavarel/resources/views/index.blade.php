@extends(template)
@section('content')
<section class="main-section">
    <div class="content">
        <h1>Home Belajar Laravel</h1>
        <p>Apa saja yang akan kamu pelajari?</p>

        <h2>* Templating Laravel</h2>
        <h2>* Login & Register dengan Auth & Session built in Laravel</h2>
        <h2>* CRUD dengan Laravel</h2>
        <h2>* Upload Image dengan Laravel</h2>
        <h2>* Perkenalan dengan Lumen (Microframework Laravel untuk Rest API)</h2>
    </div>
</section>
@endsection