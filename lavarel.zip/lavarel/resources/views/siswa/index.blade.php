@extends('template')
@section('main')
<div id="siswa"><br>
    <h2 align="center">Siswa</h2><br>

    @if (!empty($siswa_list))
    <table class="table">
        <thead>
            <tr align="center">
                <th>NISN</th>
                <th>Nama</th>
                <th>Tanggal Lahir</th>
                <th>Jenis Kelamin</th>
                <th>Kelas</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($siswa_list as $siswa) 
            <tr align="center">
                <td>{{ $siswa->nisn }}</td>
                <td>{{ $siswa->nama_siswa }}</td>
                <td>{{ $siswa->tanggal_lahir }}</td>
                <td>{{ $siswa->jenis_kelamin }}</td>
                <td>{{ ! empty ($siswa->kelas->nama_kelas) ? $siswa->kelas->nama_kelas : '-'}}</td>
                <td><a class="btn btn-success btn-sm" href="{{ url('siswa' . $siswa->id) }}">Detail</a>
                    <a class="btn btn-warning btn-sm" href="{{ url('edit' . $siswa->id) }}">Edit</a>
                    <a class="btn btn-danger btn-sm" href="{{ url('delete'. $siswa->id) }}">Delete</a></td>
            </tr>
            @endforeach
        </tbody>
    </table>
    @else
        <p>Tidak Ada Data Siswa</p>
    @endif
    <div align="center">
        <a href="{{ url('create') }}" class="btn btn-primary">Tambah Siswa</a>
    </div>
</div>
@stop

@section('footer')
    <div id="footer">
        <p align="center">&copy; 2019 Belajar_Laravel</p>
    </div>
@stop