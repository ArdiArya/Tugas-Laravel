@extends('template')

@section('main')
    <div id="siswa"><br>
        <h2 align="center">Detail Siswa</h2><br>

        <table class="table table-striped">
            <tr>
            <center>
                <img class="rounded" src="{{asset('images/'.$siswa->image) }}" width="350px" height="auto">
            </center>
            </tr>
            <br>
            <tr>
                <th>NISN</th>
                <td>{{ $siswa->nisn }}</td>
            </tr>
            <tr>
                <th>Nama</th>
                <td>{{ $siswa->nama_siswa }}</td>
            </tr>
            <tr>
                <th>Tanggal Lahir</th>
                <td>{{ $siswa->tanggal_lahir }}</td>
            </tr>
            <tr>
                <th>Jenis Kelamin</th>
                <td>{{ $siswa->jenis_kelamin }}</td>
            </tr>
            <tr>
                <th>Kelas</th>
                <td>{{ $siswa->kelas }}</td>
            </tr>
        </table>
    </div>
@stop