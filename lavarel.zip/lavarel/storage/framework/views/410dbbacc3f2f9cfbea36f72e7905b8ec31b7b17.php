<?php $__env->startSection('main'); ?>
    <div id="siswa"><br>
        <h2 align="center">Tambah Guru</h2>

        <form action="<?php echo e(url('siswa')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="nip" class="control-label">NIP</label>
                <input name="nip" type="text" class="form-control">
            </div>
            <div class="form-group">
                <label for="nama_guru" class="control-label">Nama</label>
                <input name="nama_guru" type="text" class="form-control">
            </div>
            <div class="form-group">
                <label for="tanggal_lahir" class="control-label">Tanggal Lahir</label>
                <input name="tanggal_lahir" type="date" class="form-control">
            
            <div class="form-group">
            <label for="jenis_kelamin" class="control-label">Jenis Kelamin</label>
            <div class="form-group">
                <input class="form-check-input" type="radio" name="jenis_kelamin" id="jenis_kelamin" Value="P">
                <label class="form-check label" for="jenis_kelamin">Perempuan</label>            
            </div>
            <div class="form-group">
                <input class="form-check-input" type="radio" name="jenis_kelamin" id="jenis_kelamin" Value="L">
                <label class="form-check label" for="jenis_kelamin">Laki-Laki</label>            
            </div>
            </div>
            <div align="center">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lavarel\resources\views/guru/create.blade.php ENDPATH**/ ?>