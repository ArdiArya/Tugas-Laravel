<?php $__env->startSection('main'); ?>

<div id="homepage"><br>
    <h2 align="center">Homepage</h2>
    <p align="center">Selamat Belajar Laravel</p>
</div>

<?php $__env->stopSection(); ?> 

<?php $__env->startSection('footer'); ?>
    <div id="footer">
        <p>&copy; 2019 Belajar_Laravel.ev</p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lavarel\resources\views/pages/homepage.blade.php ENDPATH**/ ?>