<?php $__env->startSection('main'); ?>
<div id="guru"><br>
<h2 align="center">Guru</h2><br>

<?php if(!empty($guru_list)): ?>
<table class="table table-striped">
  <thead>
    <tr align="center">
      <th>NIP</th>
      <th>Nama</th>
      <th>Tanggal Lahir</th>
      <th>Jenis Kelamin</th>
      <th>Aksi</th>

    </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $guru_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr align="center" >
        <td><?php echo e($guru->nip); ?></td>
        <td><?php echo e($guru->nama_guru); ?></td>
        <td><?php echo e($guru->tanggal_lahir); ?></td>
        <td><?php echo e($guru->jenis_kelamin); ?></td>
        <td>
        <a class="btn btn-success btn-sm" href="<?php echo e(url('guru' . $guru->id)); ?>">Detail</a>
        <a class="btn btn-warning btn-sm" href="<?php echo e(url('edit' . $guru->id)); ?>">Edit</a>
        <a class="btn btn-danger btn-sm" href="<?php echo e(url('guru/' . $guru->id . '/delete')); ?>">Delete</a>
        </td>


      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>

      <?php else: ?>
          <p>Tidak ada data guru</p>
      <?php endif; ?>

    <div align="center">
      <a href="<?php echo e(url('create')); ?>" class="btn btn-primary">Tambah Guru</a>
    </div>
    </div>
  <?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <div id="footer">
        <p>&copy; 2019 Belajar_Laravel</p>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lavarel\resources\views/guru/guru.blade.php ENDPATH**/ ?>