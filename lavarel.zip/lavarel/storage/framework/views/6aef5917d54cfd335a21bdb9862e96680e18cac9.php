<?php $__env->startSection('main'); ?>
<div id="mainNav">
 
<div id="about">
    <h2>About</h2>
    <p>Sistem ini dibuat sebagai latihan  <br>
        untuk mempelajari dasar laravel.</p>
</div>
   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/pages/about.blade.php ENDPATH**/ ?>