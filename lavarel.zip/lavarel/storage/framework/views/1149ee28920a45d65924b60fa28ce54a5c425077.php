<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($title); ?></title>
</head>
<body>
    <h3>
        <?php echo e($message); ?>

    </h3>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Form Registration</title>
</head>
<body>
    <h3>Form Registration</h3>
    <form action="<?php echo e(url('/send')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <table>
            <tr>
                <td>Nama</td>
                <td><input type="text" name="nama" placeholder="Nama Lengkap" required> </td>
            </tr>
            <tr>
                <td>Email</td>
                <td><input type="email" name="email" placeholder="Email" required> </td>
            </tr>
            <tr>
                <td>Telpon</td>
                <td><input type="number" name="telepon" placeholder="No. Telp." > </td>
            </tr>
            <tr>
                <td><button type="submit">Kirim</button></td>
            </tr>
        </table>
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\blog\resources\views/test_view.blade.php ENDPATH**/ ?>