<?php $__env->startSection('main'); ?>
<div id="register">
    <h2>Form Registrasi</h2>
    <form action="" method="">
        <table>
            <tr>
                <td>
                    <label for="nama">Nama</label>
                </td>
                <td> : </td>
                <td>
                    <input type="text" name="" id="">
                </td>
            </tr>
            <tr>
                <td>
                    <label for="nisn">NISN</label>
                </td>
                <td> : </td>
                <td>
                    <input type="number" name="" id="">
                </td>
            </tr>
            <tr>
                <td>
                    <label for="kelas">Kelas</label>
                </td>
                <td> : </td>
                <td>
                    <input type="text" name="" id="">
                </td>
            </tr>
            <tr>
                <td>
                    <label for="jurusan">Jurusan</label>
                </td>
                <td> : </td>
                <td>
                    <input type="text" name="" id="">
                </td>
            </tr>
            <tr>
                <td>
                    <label for="Alamat">Alamat</label>
                </td>
                <td> : </td>
                <td>
                    <input type="text" name="" id="">
                </td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td><button type="submit">Save</button> <button>Cancel</button> </td>
            </tr>
            
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/pages/register.blade.php ENDPATH**/ ?>