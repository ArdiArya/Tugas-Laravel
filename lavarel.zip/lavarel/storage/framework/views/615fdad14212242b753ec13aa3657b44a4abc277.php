<?php $__env->startSection('main'); ?>
<div id="siswa">
<h2>Siswa</h2>

<?php if(!empty($siswa_list)): ?>
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col"><h3>NISN</h3></th>
      <th scope="col"><h3>Nama</h3></th>
      <th scope="col"><h3>Tgl Lahir</h3></th>
      <th scope="col"><h3>JK</h3></th>
      <th scope="col"><h3>Aksi</h3></th>

    </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $siswa_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($siswa->nisn); ?></td>
        <td><?php echo e($siswa->nama_siswa); ?></td>
        <td><?php echo e($siswa->tanggal_lahir); ?></td>
        <td><?php echo e($siswa->jenis_kelamin); ?></td>
        <td>
        <a class="btn btn-success btn-sm" href="<?php echo e(url('siswa' . $siswa->id)); ?>">Detail</a>
        <a class="btn btn-warning btn-sm" href="<?php echo e(url('edit' . $siswa->id)); ?>">Edit</a>
        <a class="btn btn-danger btn-sm" href="<?php echo e(url('siswa/' . $siswa->id . '/delete')); ?>">Delete</a>
        </td>


      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <a href="<?php echo e(url('siswa/create')); ?>" class="btn btn-primary">Tambah Siswa</a>

      <?php else: ?>
          <p>Tidak ada data siswa</p>
      <?php endif; ?>

    </div>
  <?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <div id="footer">
        <p>&copy; 2019 Belajar_Laravel</p>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Lavarel\resources\views/siswa/index.blade.php ENDPATH**/ ?>