<?php $__env->startSection('main'); ?>
<div id="siswa"><br>
    <h2 align="center">Siswa</h2><br>

    <?php if(!empty($siswa_list)): ?>
    <table class="table">
        <thead>
            <tr align="center">
                <th>NISN</th>
                <th>Nama</th>
                <th>Tanggal Lahir</th>
                <th>Jenis Kelamin</th>
                <th>Kelas</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $siswa_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <tr align="center">
                <td><?php echo e($siswa->nisn); ?></td>
                <td><?php echo e($siswa->nama_siswa); ?></td>
                <td><?php echo e($siswa->tanggal_lahir); ?></td>
                <td><?php echo e($siswa->jenis_kelamin); ?></td>
                <td><?php echo e(! empty ($siswa->kelas->nama_kelas) ? $siswa->kelas->nama_kelas : '-'); ?></td>
                <td><a class="btn btn-success btn-sm" href="<?php echo e(url('siswa' . $siswa->id)); ?>">Detail</a>
                    <a class="btn btn-warning btn-sm" href="<?php echo e(url('edit' . $siswa->id)); ?>">Edit</a>
                    <a class="btn btn-danger btn-sm" href="<?php echo e(url('delete'. $siswa->id)); ?>">Delete</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
        <p>Tidak Ada Data Siswa</p>
    <?php endif; ?>
    <div align="center">
        <a href="<?php echo e(url('create')); ?>" class="btn btn-primary">Tambah Siswa</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <div id="footer">
        <p align="center">&copy; 2019 Belajar_Laravel</p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lavarel\resources\views/siswa/index.blade.php ENDPATH**/ ?>