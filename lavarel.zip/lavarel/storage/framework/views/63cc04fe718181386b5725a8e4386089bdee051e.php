<br>
<br>
<br>
<section class="copyright py-3 text-center text-white" style="position:fixed; width:100%; bottom:0px;">
    <div class="container">
      <small>&copy; 2019 Belajar_Laravel</small>
    </div>
  </section>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/footer.blade.php ENDPATH**/ ?>