<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', 'Homecontroller@index');
Route::get('home', 'pagescontroller@homepage');
Route::get('about', 'pagescontroller@about');
Route::get('siswa', 'siswacontroller@siswa');
Route::get('register', 'pagescontroller@register');
Route::get('create', 'siswacontroller@create');
Route::post('siswa', 'siswacontroller@store');
Route::get('siswa{siswa}', 'siswacontroller@show');
Route::get('edit{siswa}', 'siswacontroller@edit');
Route::post('siswa/{siswa}/update', 'siswacontroller@update');
Route::get('delete{siswa}', 'siswacontroller@delete');
Route::get('form', function() {
    return view('pages.formview');

Route::get('/', 'kontak@index');
});
//guru

Route::get('guru', 'gurucontroller@guru');
Route::get('register', 'pagescontroller@register');
Route::get('guru/create', 'gurucontroller@create');
Route::post('guru', 'gurucontroller@store');
Route::get('guru{guru}', 'gurucontroller@show');
Route::get('edit{guru}', 'gurucontroller@edit');
Route::post('update{guru}', 'gurucontroller@update');
Route::get('delete{guru}', 'gurucontroller@delete');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
